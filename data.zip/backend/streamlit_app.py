import streamlit as st
from PIL import Image
import cv2
import numpy as np
import time
from tensorflow.keras.models import load_model
# Load your ML model
model = load_model('D:\\Hackathon_project\\backend\\model.keras')


def process_image(image):
    image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    resized_image = cv2.resize(image, (180, 180))
    normalized_image = resized_image / 255.0
    normalized_image = np.expand_dims(normalized_image, axis=0)  # Add batch dimension

    result = model.predict(normalized_image)
    predicted_class = np.argmax(result, axis=1)[0]

    return 'defect_detected' if predicted_class == 1 else 'no_defect'

st.title("Enhance 3D - Real-Time Monitoring & Defect Detection")

# Option to upload an image
uploaded_file = st.file_uploader("Upload an image for defect detection", type=["jpg", "jpeg", "png"])

# Option to use the camera
if st.checkbox("Use Camera"):
    camera_input = st.camera_input("Capture an image for defect detection")
    if camera_input:
        image = Image.open(camera_input)
        st.image(image, caption="Captured Image", use_column_width=True)
        with st.spinner('Processing image...'):
            result = process_image(image)
        st.write(f"Result: {result}")

elif uploaded_file is not None:
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Image", use_column_width=True)
    with st.spinner('Processing image...'):
        result = process_image(image)
    st.write(f"Result: {result}")

# Display the output or a suitable message
if 'result' in locals():
    if result == 'defect_detected':
        st.error("Defect detected during 3D printing!")
    else:
        st.success("No defects detected!")
